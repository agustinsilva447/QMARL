# Examples using the IP Core ComBlock

* [measurements](measurements): a design to measure the resources utilization.
* [test](test): a design to exercise write and read of the different interfaces.
